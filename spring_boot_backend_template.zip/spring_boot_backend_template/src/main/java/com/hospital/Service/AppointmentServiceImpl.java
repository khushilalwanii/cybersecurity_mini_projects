package com.hospital.Service;

import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Service;

import com.hospital.customException.ResourceNotFoundException;
import com.hospital.dtos.AppointmentRequestDto;
import com.hospital.entities.Appointment;
import com.hospital.entities.Doctor;
import com.hospital.repository.AppointmentRepository;
import com.hospital.repository.DoctorRepository;

import jakarta.transaction.Transactional;
import lombok.RequiredArgsConstructor;

@Service
@Transactional
@RequiredArgsConstructor
public class AppointmentServiceImpl implements AppointmentService{
	private final DoctorRepository doctorRepo;
	private final AppointmentRepository appRepo;
	private final ModelMapper modelMapper;

	@Override
	public String addAppointment(AppointmentRequestDto ReqDto) {
		Doctor doctor = doctorRepo.findById(ReqDto.getDoctorId()).orElseThrow(()-> new ResourceNotFoundException("not found"));
		Appointment app = modelMapper.map(ReqDto, Appointment.class);
		app.setDoctor(doctor);
		appRepo.save(app);
		return "appointment added";
	}

}
