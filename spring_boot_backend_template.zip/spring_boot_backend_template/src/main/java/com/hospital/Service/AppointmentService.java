package com.hospital.Service;

import com.hospital.dtos.AppointmentRequestDto;

public interface AppointmentService {
	String addAppointment(AppointmentRequestDto ReqDto);

}
