package com.hospital.Service;

public interface DoctorService {

}
