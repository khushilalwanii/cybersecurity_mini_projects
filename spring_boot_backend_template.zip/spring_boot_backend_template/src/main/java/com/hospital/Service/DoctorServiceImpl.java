package com.hospital.Service;

public class DoctorServiceImpl implements DoctorService{

}
