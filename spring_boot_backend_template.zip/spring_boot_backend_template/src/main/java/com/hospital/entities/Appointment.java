package com.hospital.entities;

import java.time.LocalDate;

import org.springframework.data.annotation.CreatedDate;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Table(name = "Appointments")
@Getter
@Setter
@NoArgsConstructor

public class Appointment {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	@Column(name = "Patient_Name")
	private String patientName;
	@Column(name = "Patient_Email")
	private String patientEmail;
	
	private LocalDate appointmentDate;
	private double fees;
	@Enumerated(EnumType.STRING)
	private Status status;
	@ManyToOne
	@JoinColumn(name = "docotrId")
	private Doctor doctor;
	public Appointment(String patientName, String patientEmail, LocalDate appointmentDate, double fees, Status status,
			Doctor doctor) {
		super();
		this.patientName = patientName;
		this.patientEmail = patientEmail;
		this.appointmentDate = appointmentDate;
		this.fees = fees;
		this.status = status;
		this.doctor = doctor;
	}
	

}
