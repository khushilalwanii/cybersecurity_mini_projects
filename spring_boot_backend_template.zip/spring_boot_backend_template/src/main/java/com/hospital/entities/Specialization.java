package com.hospital.entities;

public enum Specialization {
	CARDIOLOGY, DERMATOLOGY, NEUROLOGY

}
