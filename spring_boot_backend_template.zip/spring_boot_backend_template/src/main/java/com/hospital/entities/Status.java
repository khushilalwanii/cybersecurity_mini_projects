package com.hospital.entities;

public enum Status {
	SCHEDULED, COMPLETED, CANCELLED
}
