package com.hospital.entities;

import java.time.LocalDate;

import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Table(name = "Doctors")
@Getter
@Setter
@NoArgsConstructor
public class Doctor {

	public Doctor(String name, String email, Specialization specialization, String city, int experience) {
		super();
		this.name = name;
		this.email = email;
		this.specialization = specialization;
		this.city = city;
		this.experience = experience;
	}
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	private String name;
	private String email;
	@Enumerated(EnumType.STRING)
	private Specialization specialization;
	private String city;
	private int experience;
	
	
	
}
