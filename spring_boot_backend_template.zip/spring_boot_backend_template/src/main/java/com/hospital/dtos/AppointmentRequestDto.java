package com.hospital.dtos;

import lombok.Data;

@Data
public class AppointmentRequestDto {
	private Long doctorId;
	private String patientName;
	private String patientEmail;
	private double fees;
	

}
