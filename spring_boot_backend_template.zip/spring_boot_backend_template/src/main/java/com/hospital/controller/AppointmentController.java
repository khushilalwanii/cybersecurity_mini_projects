package com.hospital.controller;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.hospital.Service.AppointmentService;
import com.hospital.dtos.AppointmentRequestDto;

import lombok.RequiredArgsConstructor;

@RestController
@RequiredArgsConstructor
@RequestMapping("/appointments")
public class AppointmentController {
	private final AppointmentService appService;
	
	@PostMapping
	public ResponseEntity<String> addApp(@RequestBody AppointmentRequestDto dto){
		String msg = appService.addAppointment(dto);
		return ResponseEntity.ok(msg);
	}

}
